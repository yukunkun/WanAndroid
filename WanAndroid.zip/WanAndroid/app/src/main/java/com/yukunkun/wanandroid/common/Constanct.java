package com.yukunkun.wanandroid.common;

/**
 * Created by yukun on 18-1-4.
 */

public class Constanct {
    public static String FEEDURL="http://www.wanandroid.com/article/list/";
    public static String TREEURL="http://www.wanandroid.com/tree/json";
    public static String LOGINURL ="http://www.wanandroid.com/user/login";
    public static String ZHUCEURL ="http://www.wanandroid.com/user/register";
    public static String SEARCHHOT="http://www.wanandroid.com/hotkey/json";
    public static String COMMONURL="http://www.wanandroid.com/friend/json";
    public static String SEARCH="http://www.wanandroid.com/article/query/";
    public static String COLLECTURL="http://www.wanandroid.com/lg/collect/";
    public static String CANCELCOLURL="http://www.wanandroid.com/lg/uncollect/";
    public static String COLLECTLIST="http://www.wanandroid.com/lg/collect/usertools/json";
    public static String KNOWLEDGELISTURL="http://www.wanandroid.com/article/list/";
}
