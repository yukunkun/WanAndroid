package com.yukunkun.wanandroid.enerty;

/**
 * Created by yukun on 18-1-5.
 */

public class EventLoginType {
    public int logintype;

    public EventLoginType(int logintype) {
        this.logintype = logintype;
    }
}
