### WanAndroid的APP版本，基于张鸿洋的玩Android网站开放的api
#### 基本功能已经完成，下面是截图。
[APK下载](https://github.com/yukunkun/WanAndroid/tree/master/apk)

![S80108-15475901.jpg](http://upload-images.jianshu.io/upload_images/3001453-6c3fa9e431e66070.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![S80108-15472704.jpg](http://upload-images.jianshu.io/upload_images/3001453-5575f6839b6ca8ea.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![S80108-15471685.jpg](http://upload-images.jianshu.io/upload_images/3001453-fa29119632aa6368.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![S80108-15472334.jpg](http://upload-images.jianshu.io/upload_images/3001453-098108d0cd10c01c.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![S80108-15492222.jpg](http://upload-images.jianshu.io/upload_images/3001453-c2f93ce9c69d8bba.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![S80108-15473870.jpg](http://upload-images.jianshu.io/upload_images/3001453-00c56104e19f2ede.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![S80108-15470951.jpg](http://upload-images.jianshu.io/upload_images/3001453-2482de296093eb5e.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![S80108-15482097.jpg](http://upload-images.jianshu.io/upload_images/3001453-53a176fa2de00a48.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
